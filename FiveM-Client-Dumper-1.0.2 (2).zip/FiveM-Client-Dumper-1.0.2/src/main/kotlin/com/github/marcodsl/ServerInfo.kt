package com.github.marcodsl

data class ServerInfo(
    val server: String,
    val resources: List<String>
)