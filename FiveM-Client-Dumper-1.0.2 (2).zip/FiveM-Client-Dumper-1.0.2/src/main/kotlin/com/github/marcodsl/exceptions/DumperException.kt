package com.github.marcodsl.exceptions

class DumperException(cause: String) : Exception(cause)