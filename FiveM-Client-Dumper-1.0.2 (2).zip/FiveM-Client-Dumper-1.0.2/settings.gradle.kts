rootProject.name = "fivem-client-dumper"

